package br.com.lenara.projeto1labBeach;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto1labBeachApplicationTests {

	@Test
	void contextLoads() {
	}

}
