package br.com.lenara.projeto1labBeach;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projeto1labBeachApplication {

	public static void main(String[] args) {
		SpringApplication.run(Projeto1labBeachApplication.class, args);
	}

}
